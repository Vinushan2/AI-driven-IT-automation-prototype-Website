/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // 🌈 Neon Theme
        'neon-violet': '#8B5CF6',
        'neon-cyan': '#06B6D4',
        'neon-blue': '#3B82F6',
        'neon-yellow': '#FF9F00',

        // 🧊 Soft & Dark
        'ice-blue': '#E0F2FE',
        'dark-bg': '#0A0B14',
        'dark-surface': '#1A1B2E',
        'dark-card': '#16213E',
      },
      backgroundImage: {
        // 🎨 Gradient Utilities
        'gradient-cyan-yellow': 'linear-gradient(to right, #06B6D4, #FF9F00)',
        'gradient-yellow-cyan-violet': 'linear-gradient(to right, #FF9F00, #06B6D4, #8B5CF6)',
        'gradient-yellow-blue': 'linear-gradient(to right, #FF9F00, #3B82F6)',
        'gradient-violet-cyan': 'linear-gradient(to right, #8B5CF6, #06B6D4)',
        'radial-faint': 'radial-gradient(circle at top left, rgba(255,159,0,0.2), transparent)',
      },
      animation: {
        // 🎥 Custom Animations
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'slide-up': 'slideUp 0.6s ease-out',
        'fade-in': 'fadeIn 0.8s ease-out',
        'tilt': 'tilt 10s infinite linear',
      },
      keyframes: {
        glow: {
          '0%': {
            boxShadow: '0 0 5px #06B6D4, 0 0 10px #06B6D4, 0 0 15px #06B6D4',
          },
          '100%': {
            boxShadow: '0 0 10px #06B6D4, 0 0 20px #06B6D4, 0 0 30px #06B6D4',
          },
        },
        slideUp: {
          '0%': { transform: 'translateY(100px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        tilt: {
          '0%, 50%, 100%': { transform: 'rotate(0deg)' },
          '25%': { transform: 'rotate(1deg)' },
          '75%': { transform: 'rotate(-1deg)' },
        },
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Menlo', 'Monaco', 'Consolas', 'monospace'],
      },
      backdropBlur: {
        xs: '2px',
        sm: '4px',
      },
      borderRadius: {
        '2xl': '1.25rem',
        '3xl': '1.5rem',
      },
      boxShadow: {
        glow: '0 0 20px rgba(6, 182, 212, 0.6)',
        neon: '0 0 10px #FF9F00, 0 0 20px #FF9F00',
      },
      scale: {
        98: '0.98',
      },
    },
  },
  plugins: [],
};
