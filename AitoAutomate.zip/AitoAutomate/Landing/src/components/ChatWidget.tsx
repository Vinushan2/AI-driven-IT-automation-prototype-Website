import { useState, useRef, useEffect } from 'react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Hey there! Lumi’s here to brighten your day. What’s up?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const toggleChat = () => setIsOpen(prev => !prev);

  const sendMessage = async () => {
  if (!input.trim()) return;

  const newMessages = [...messages, { role: 'user', content: input }];
  setMessages(newMessages);
  setInput('');
  setLoading(true);

  try {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'llama3-8b-8192',  // your model here
        messages: newMessages
      })
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.error?.message || 'API request failed');
    }

    const data = await res.json();
    const reply = data.choices[0]?.message;
    setMessages([...newMessages, reply]);
  } catch (err) {
    console.error('Chat API error:', err);
    setMessages([...newMessages, { role: 'assistant', content: 'Something went wrong. Try again later.' }]);
  }

  setLoading(false);
};


  // Scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  return (
    <>
      {/* Floating Chatbot Icon */}
      <div
  onClick={toggleChat}
  className="fixed bottom-6 right-6 z-50 cursor-pointer transition-transform transform hover:scale-110"
  title="Chat with us"
  style={{
    animation: 'floatUpDown 3s ease-in-out infinite',
  }}
>
  <img
    src="/chatbot.png"
    alt="Chatbot Icon"
    className="w-10 h-10"
    style={{ width: '200px', height: '130px' }}
  />
</div>

<style>
  {`
    @keyframes floatUpDown {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-15px);
      }
    }
  `}
</style>


      {/* Chat Popup */}
      {isOpen && (
        <div
          className="fixed bottom-24 right-6 w-96 bg-[#0f172a] border border-[#0ea5e9] rounded-2xl shadow-neonBlue p-4 z-50 font-mono text-sm text-[#cbd5e1] flex flex-col"
          style={{
            boxShadow:
              '0 0 10px #0ea5e9, 0 0 20px #3b82f6, 0 0 30px #0ea5e9 inset',
          }}
        >
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto space-y-3 mb-3 px-2"
            style={{ scrollbarWidth: 'thin', scrollbarColor: '#0ea5e9 transparent' }}
          >
            {messages.map((m, i) => (
              <div
                key={i}
                className={`max-w-[80%] p-2 rounded-lg ${
                  m.role === 'user'
                    ? 'ml-auto bg-gradient-to-tr from-[#0ea5e9]/80 to-[#3b82f6]/70 text-white shadow-neonBlue'
                    : 'bg-[#1e293b] border border-[#0ea5e9] text-[#a5b4fc]'
                }`}
                style={{
                  boxShadow:
                    m.role === 'user'
                      ? '0 0 10px #0ea5e9, 0 0 20px #3b82f6'
                      : '0 0 8px #0ea5e9 inset',
                }}
              >
                <p>{m.content}</p>
              </div>
            ))}
            {loading && (
              <p className="text-[#94a3b8] italic select-none">Thinking...</p>
            )}
          </div>

          <div className="flex gap-0">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && sendMessage()}
              className="flex-1 bg-[#1e293b] border border-[#0ea5e9] text-white rounded-l-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#3b82f6]"
              placeholder="Ask something..."
              autoFocus
            />
            <button
              onClick={sendMessage}
              disabled={loading}
              className="bg-gradient-to-r from-[#0ea5e9] to-[#3b82f6] hover:from-[#3b82f6] hover:to-[#0ea5e9] text-white rounded-r-lg px-5 py-2 font-semibold disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}
