import React from "react";
import { Link } from "react-router-dom";
import {
  FaFacebookF as Facebook,
  FaTwitter as Twitter,
  FaYoutube as Youtube,
  FaLinkedin as Linkedin,
  FaQuora as Quora,
} from "react-icons/fa";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0a0a10] text-gray-400 pt-16 border-t border-gradient-to-r from-yellow-400/30 via-blue-400/30 to-yellow-400/30 shadow-inner shadow-yellow-500/5 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid md:grid-cols-4 gap-10">
          {/* Brand + Description */}
          <div className="md:col-span-2 space-y-4">
            <Link to="/" className="inline-flex items-center space-x-3">
              <div className="h-12 w-[140px] overflow-hidden">
                <img
                  src="/logo.png"
                  alt="Logo"
                  className="h-full w-auto drop-shadow-md transform transition-transform duration-200 hover:scale-105 will-change-transform"
                />
              </div>
              <span className="text-xl font-semibold text-white tracking-wide">
                Automate AI
              </span>
            </Link>
            <p className="text-gray-400 leading-relaxed max-w-md">
              Empower your IT infrastructure with AI-driven automation. Predict
              issues, streamline operations, and optimize performance with
              cutting-edge technology.
            </p>

            {/* Social Icons */}
            <div className="flex space-x-4 pt-2">
              <SocialIcon
                href="https://www.facebook.com/theaitoautomate/"
                label="Facebook"
                Icon={Facebook}
                color="#00BFFF"
              />
              <SocialIcon
                href="https://x.com/theaitoautomate"
                label="Twitter"
                Icon={Twitter}
                color="#1DA1F2"
              />
              <SocialIcon
                href="https://www.youtube.com/@Theaitoautomate"
                label="YouTube"
                Icon={Youtube}
                color="#FF0000"
              />
              <SocialIcon
                href="https://www.linkedin.com/company/theaitoautomate/"
                label="LinkedIn"
                Icon={Linkedin}
                color="#0077b5"
              />
              <SocialIcon
                href="https://www.quora.com/profile/Theaitoautomate"
                label="Quora"
                Icon={Quora}
                color="#B92B27"
              />
              <SocialImageIcon
                href="https://www.crunchbase.com/organization/automate-ai"
                alt="Crunchbase"
                src="/cb.png"
              />
              <SocialImageIcon
                href="https://www.f6s.com/automate-ai"
                alt="F6S"
                src="/f6s.png"
              />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold mb-4 text-lg tracking-wide">
              Quick Links
            </h3>
            <ul className="space-y-2 text-sm">
              {["solutions", "pricing", "blog", "contact"].map((path) => (
                <li key={path}>
                  <Link
                    to={`/${path}`}
                    className="hover:text-yellow-400 transition-colors duration-200 hover:underline"
                  >
                    {path.charAt(0).toUpperCase() + path.slice(1)}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white font-bold mb-4 text-lg tracking-wide">
              Legal
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  to="/privacy"
                  className="hover:text-cyan-400 transition-colors duration-200 hover:underline"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  to="/terms"
                  className="hover:text-cyan-400 transition-colors duration-200 hover:underline"
                >
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-yellow-400/20 pt-6 text-sm text-center md:text-left">
          <p>© {currentYear} TheAIToAutomate.com. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

// Social icon component
function SocialIcon({ href, label, Icon, color }) {
  return (
    <a
      href={href}
      aria-label={label}
      className="group text-[#00BFFF] hover:text-white transition duration-300"
      target="_blank"
      rel="noopener noreferrer"
    >
      <Icon
        className="icon"
        style={{
          width: "20px",
          height: "20px",
          transition: "transform 0.3s ease",
          willChange: "transform",
        }}
      />
    </a>
  );
}

// Image-based social icons (Crunchbase, F6S)
function SocialImageIcon({ href, alt, src }) {
  return (
    <a
      href={href}
      aria-label={alt}
      className="group"
      target="_blank"
      rel="noopener noreferrer"
    >
      <img
        src={src}
        alt={alt}
        className="icon"
        style={{
          width: "20px",
          height: "20px",
          transition: "transform 0.3s ease",
          willChange: "transform",
        }}
      />
    </a>
  );
}
