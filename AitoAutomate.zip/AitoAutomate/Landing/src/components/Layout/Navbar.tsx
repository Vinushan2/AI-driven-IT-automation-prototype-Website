import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Bot, Menu, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

export default function Navbar() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/solutions', label: 'Solutions' },
    { path: '/pricing', label: 'Pricing' },
    { path: '/blog', label: 'Blog' },
    { path: '/contact', label: 'Contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0c0c14]/90 backdrop-blur-md border-b border-yellow-400/30 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            
            <img 
  src="/logo.png" 
  alt="Logo" 
  className="logo" 
  style={{ height: '50px', width: '100px' }} 
/>

          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`relative px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                  location.pathname === item.path
                    ? 'text-yellow-400 drop-shadow-[0_0_10px_rgba(255,215,0,0.8)]'
                    : 'text-gray-300 hover:text-yellow-400 hover:drop-shadow-[0_0_6px_rgba(255,215,0,0.7)]'
                }`}
              >
                {item.label}
                {location.pathname === item.path && (
                  <motion.div
                    layoutId="navbar-indicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-yellow-400 rounded-full shadow-yellow-400"
                    style={{
                      filter:
                        "drop-shadow(0 0 6px rgba(255, 215, 0, 0.9))",
                    }}
                  />
                )}
              </Link>
            ))}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-gray-300 hover:text-yellow-400"
            aria-label="Toggle Menu"
          >
            {isOpen ? (
              <X className="h-6 w-6 text-yellow-400 drop-shadow-[0_0_8px_rgba(255,215,0,0.9)]" />
            ) : (
              <Menu className="h-6 w-6 text-[#00BFFF] drop-shadow-[0_0_8px_rgba(0,191,255,0.9)]" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="md:hidden bg-[#111119]/95 backdrop-blur-md border-b border-yellow-400/30 shadow-lg"
        >
          <div className="px-4 py-2 space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`block px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  location.pathname === item.path
                    ? 'text-yellow-400 bg-yellow-400/20 drop-shadow-[0_0_8px_rgba(255,215,0,0.8)]'
                    : 'text-gray-300 hover:text-yellow-400 hover:bg-yellow-400/10 hover:drop-shadow-[0_0_6px_rgba(255,215,0,0.7)]'
                }`}
              >
                {item.label}
              </Link>
            ))}
            <a
  href="https://app.TheAIToAutomate.com"
  target="_blank"
  rel="noopener noreferrer"
  className="block w-full text-center bg-gradient-to-r from-yellow-400 to-[#00BFFF] px-4 py-2 rounded-lg text-white font-medium mt-4 drop-shadow-[0_0_8px_rgba(255,215,0,0.9)]"
>
  Dashboard
</a>

          </div>
        </motion.div>
      )}
    </nav>
  );
}
