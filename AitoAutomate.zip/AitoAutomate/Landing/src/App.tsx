import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Layout/Navbar';
import Footer from './components/Layout/Footer';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Home from './pages/Home';
import Contact from './pages/Contact';
import Pricing from './pages/Pricing';
import Blog from './pages/Blog';
import Solutions from './pages/Solutions';
import NotFound from './pages/NotFound';
import ChatWidget from './components/ChatWidget'; // 👈 Import ChatWidget
import './index.css'; // Global styles

function App() {
  useEffect(() => {
    setTimeout(() => {
      console.clear();
      console.log('%c🧠 Welcome, Curious Dev!', 'color:#fff; background:#1e1e1e; font-size:20px; padding:8px 12px; border-radius:6px;');
      console.log('%c🚀 Powered by Vinu • theaitoautomate.com', 'color:#000; background:#FFEB3B; font-weight:bold; padding:4px 8px; border-radius:4px;');
      console.log('%c💡 Try typing `triggerSelfDestruct()`, `rickRoll()`, or `glitchMode()` in console!', 'color:#00BFFF; font-size:12px;');

      (window as any).triggerSelfDestruct = () => {
        alert("🔥 Self-Destruct Activated (just kidding 🤣)");
        window.location.href = "/NotFound";
      };

      (window as any).rickRoll = () => {
        window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "_blank");
      };

      (window as any).glitchMode = () => {
        document.body.classList.toggle('glitch');
      };
    }, 1500);

    const secret = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65];
    let input: number[] = [];
    const onKeyDown = (e: KeyboardEvent) => {
      input.push(e.keyCode);
      input = input.slice(-secret.length);
      if (secret.every((v, i) => v === input[i])) {
        alert("🎮 Konami Code Entered! Secret mode unlocked.");
        document.body.style.background = '#0f0';
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-dark-bg text-white relative">
        {/* 🔒 Hidden Signature */}
        <span
          style={{
            opacity: 0,
            position: 'absolute',
            pointerEvents: 'none',
            fontSize: '0.001px',
            userSelect: 'none',
          }}
        >
          theaitoautomate_signature_vinu2025
        </span>

        <Routes>
          <Route
            path="/*"
            element={
              <>
                <Navbar />
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/solutions" element={<Solutions />} />
                  <Route path="/pricing" element={<Pricing />} />
                  <Route path="/blog" element={<Blog />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/privacy" element={<Privacy />} />
                  <Route path="/terms" element={<Terms />} />
                  <Route path="/NotFound" element={<NotFound />} />
                </Routes>
                <Footer />
              </>
            }
          />
        </Routes>

        {/* 🧠 ChatWidget shown on all pages */}
        <ChatWidget />
      </div>
    </Router>
  );
}

export default App;
