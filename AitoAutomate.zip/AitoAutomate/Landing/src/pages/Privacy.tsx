import React from 'react';

function Privacy() {
  return (
    <div className="max-w-5xl mx-auto py-16 px-6 text-gray-100 space-y-10">
      {/* Header */}
      <div className="space-y-2 text-center">
        <h1 className="text-4xl font-bold text-white">Privacy Policy</h1>
        <p className="text-sm text-gray-400">Last updated: June 26, 2025</p>
      </div>

      {/* Terms Summary */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4">
        <p>These terms govern your access and use of our website and services. By using our site, you agree to these Terms.</p>
        <p className="text-sm text-blue-400">
          Generated using <a href="https://www.termsfeed.com/terms-conditions-generator/" target="_blank" rel="noopener noreferrer" className="underline">Terms & Conditions Generator</a>
        </p>
      </div>

      {/* Privacy Policy Overview */}
      <div className="bg-gray-900 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Privacy Policy</h2>
        <p>This Privacy Policy describes our policies and procedures on the collection, use and disclosure of your information when you use the Service and tells you about your privacy rights and how the law protects you.</p>
        <p>We use your personal data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this Privacy Policy.</p>
        <p className="text-sm text-blue-400">
          Created with the help of <a href="https://www.termsfeed.com/privacy-policy-generator/" target="_blank" className="underline">Privacy Policy Generator</a>.
        </p>
      </div>

      {/* Interpretation and Definitions */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4">
        <h3 className="text-xl font-semibold">Interpretation</h3>
        <p>The words with capital letters have meanings defined under the following conditions. These definitions apply regardless of singular or plural usage.</p>
        <h3 className="text-xl font-semibold pt-4">Definitions</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-300">
          {[
            { term: 'Account', def: 'A unique account created for You to access our Service.' },
            { term: 'Affiliate', def: 'An entity under common control with a party.' },
            { term: 'Company', def: 'Automate AI, also referred to as "We", "Us" or "Our".' },
            { term: 'Cookies', def: 'Small files that track and store usage data.' },
            { term: 'Country', def: 'Sri Lanka.' },
            { term: 'Device', def: 'Any device that can access the Service such as a computer, phone, or tablet.' },
            { term: 'Personal Data', def: 'Any information related to an identified or identifiable individual.' },
            { term: 'Service', def: 'Refers to the Website theaitoautomate.com.' },
            { term: 'Service Provider', def: 'Any party processing data on behalf of the Company.' },
            { term: 'Third-party Social Media Service', def: 'Any social login platform like Google, Facebook, etc.' },
            { term: 'Usage Data', def: 'Automatically collected data like IP address, browser version, etc.' },
            { term: 'Website', def: 'TheAIToAutomate.com accessible at https://theaitoautomate.com/' },
            { term: 'You', def: 'The individual or entity accessing or using the Service.' },
          ].map(({ term, def }) => (
            <div key={term} className="bg-gray-700 p-4 rounded-md shadow">
              <p className="font-bold">{term}</p>
              <p>{def}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Your Responsibilities */}
      <div className="bg-gray-900 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Your Responsibilities</h2>
        <ul className="list-disc list-inside space-y-1 text-gray-300">
          <li>Provide accurate and current information.</li>
          <li>Use the Service lawfully.</li>
          <li>Not use it to harm others or for fraudulent purposes.</li>
        </ul>
      </div>

      {/* Acknowledgment */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Acknowledgment</h2>
        <p>By using our Service, you agree to comply with these Terms. If you disagree, do not use our Service.</p>
      </div>

      {/* Termination */}
      <div className="bg-gray-900 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Termination</h2>
        <p>We may terminate or suspend access if you breach the Terms without notice or liability.</p>
      </div>

      {/* Limitation of Liability */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Limitation of Liability</h2>
        <p>We are not liable for indirect or consequential damages resulting from your use of the Service.</p>
      </div>

      {/* Governing Law */}
      <div className="bg-gray-900 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Governing Law</h2>
        <p>These Terms are governed by the laws of your country, excluding conflict of law rules.</p>
      </div>

      {/* Privacy Policy – Usage & Sharing */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Use and Sharing of Your Personal Data</h2>
        <p>The Company may use Personal Data to manage your account, provide the service, analyze usage, and send updates or promotional offers.</p>
        <p>We may share data with Service Providers, Affiliates, Business Partners, and others with your consent or where legally required.</p>
      </div>

      {/* Cookies */}
      <div className="bg-gray-900 p-6 rounded-xl shadow-lg space-y-4">
        <h2 className="text-2xl font-semibold">Cookies and Tracking</h2>
        <p>We use session and persistent cookies for essential functionality, analytics, and personalization. You may control cookies via browser settings.</p>
        <p className="text-sm text-blue-400">
          Learn more about cookies on the <a href="https://www.termsfeed.com/blog/cookies/#What_Are_Cookies" target="_blank" className="underline">TermsFeed website</a>.
        </p>
      </div>

      {/* Contact Section */}
      <div className="bg-gray-800 p-6 rounded-xl shadow-lg space-y-4 text-center">
        <h2 className="text-2xl font-semibold">Contact Us</h2>
        <p>Email: <a href="mailto:support@theaitoautomate.com" className="text-blue-400 underline">support@theaitoautomate.com</a></p>
        <p>Website: <a href="https://TheAIToAutomate.com" className="text-blue-400 underline" target="_blank" rel="noopener noreferrer">TheAIToAutomate.com</a></p>
      </div>
    </div>
  );
}

export default Privacy;
