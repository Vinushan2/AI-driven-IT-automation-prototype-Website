import React from 'react';
import { motion } from 'framer-motion';
import { Check, Bot, Zap, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Pricing() {
  const plans = [
    
  {
    name: 'Free Trial',
    price: '$0',
    period: '14 days',
    description: 'Perfect for testing our AI automation capabilities',
    features: [
      'Up to 5 servers monitoring',
      'Basic AI insights',
      'Email alerts',
      '24/7 community support',
      'Standard integrations'
    ],
    cta: 'Start Free Trial',
    ctaLink: '/contact',  // ✅ link to contact page
    popular: false,
  },
  {
    name: 'Standard',
    price: '$99',
    period: 'per month',
    description: 'Ideal for growing teams and medium-sized infrastructure',
    features: [
      'Up to 50 servers monitoring',
      'Groq-Powered AI Insights',
      'Predictive maintenance alerts',
      'Custom automation workflows',
      'Priority email support',
      'Advanced integrations',
      'Performance analytics'
    ],
    cta: 'Get Started',
    ctaLink: '/contact',  // ✅ link to contact page
    popular: true,
  },
  {
    name: 'Pro',
    price: '$299',
    period: 'per month',
    description: 'Advanced features for large-scale operations',
    features: [
      'Unlimited servers monitoring',
      'Advanced AI recommendations',
      'Real-time incident response',
      'Custom AI model training',
      'Dedicated account manager',
      'Phone & chat support',
      'White-label options',
      'API access'
    ],
    cta: 'Contact Sales',
    ctaLink: '/contact',  // ✅ link to contact page
    popular: false,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'pricing',
    description: 'Tailored solutions for enterprise-grade requirements',
    features: [
      'Unlimited everything',
      'Custom AI model development',
      'On-premise deployment',
      'Advanced security controls',
      'SLA guarantees',
      '24/7 dedicated support',
      'Custom integrations',
      'Training & onboarding'
    ],
    cta: 'Contact Sales',
    ctaLink: '/contact',  // ✅ link to contact page
    popular: false,
  }
];


  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 60 } },
  };

  return (
    <div className="relative min-h-screen bg-[#0D0D0D] text-white py-20 px-4 overflow-hidden">
      {/* Background Animated Gradient */}
      <div
        className="absolute inset-0 -z-10 animate-gradient bg-gradient-to-r from-[#4DA8FF] via-[#FFC107] to-[#4DA8FF] opacity-30"
        style={{
          backgroundSize: '600% 600%',
          animation: 'gradientShift 20s ease infinite',
        }}
      />

      {/* Animated Glowing Lines */}
      <div className="absolute inset-0 -z-20">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-[150%] h-[2px] bg-cyan-400 opacity-10 blur-md animate-line"
            style={{
              top: `${i * 20 + 10}%`,
              left: `-${i * 10}%`,
              animationDelay: `${i * 3}s`,
              transform: 'rotate(45deg)',
            }}
          />
        ))}
      </div>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-center mb-20"
      >
        <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight">
          <span className="bg-gradient-to-r from-[#4DA8FF] to-[#FFC107] bg-clip-text text-transparent">
            Simple Pricing
          </span>
        </h1>
        <p className="text-lg md:text-xl text-gray-400 mt-6 max-w-2xl mx-auto">
          Choose the perfect plan for your AI automation needs. All plans include our core features with varying levels of scale and support.
        </p>
      </motion.div>

      {/* Pricing Cards */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
      >
        {plans.map((plan, index) => (
  <motion.div key={index} variants={cardVariants}>
    <div
      className={`relative bg-[#1A1A1A] p-8 rounded-2xl border ${
        plan.popular
          ? 'border-[#4DA8FF] shadow-[0_0_20px_#4DA8FFAA] scale-105'
          : 'border-[#4DA8FF]/30 hover:border-[#4DA8FF]/70'
      } transition-all duration-300`}
    >
      {plan.popular && (
        <div className="absolute -top-5 left-1/2 transform -translate-x-1/2">
          <span className="bg-gradient-to-r from-[#4DA8FF] to-[#FFC107] px-4 py-1 rounded-full text-sm font-semibold text-black">
            Most Popular
          </span>
        </div>
      )}

      <div className="text-center mb-8">
        <h3 className="text-2xl font-semibold mb-2 text-[#4DA8FF]">{plan.name}</h3>
        <div className="mb-4">
          <span className="text-4xl font-bold">{plan.price}</span>
          {plan.period && <span className="text-gray-400 ml-2">/{plan.period}</span>}
        </div>
        <p className="text-gray-300">{plan.description}</p>
      </div>

      <ul className="list-disc pl-6 text-sm text-gray-400 space-y-2 mb-8">
        {plan.features.map((feature, i) => (
          <li key={i}>{feature}</li>
        ))}
      </ul>

      <Link to={plan.ctaLink}>
        <button
          className={`w-full py-3 rounded-xl font-semibold text-black transition-shadow duration-300 ${
            plan.popular
              ? 'bg-gradient-to-r from-[#4DA8FF] to-[#FFC107] shadow-[0_0_15px_#4DA8FFAA] hover:shadow-[0_0_30px_#FFC107]'
              : 'bg-[#4DA8FF]/20 hover:bg-[#4DA8FF]/40 text-[#4DA8FF]'
          }`}
        >
          {plan.cta}
        </button>
      </Link>
    </div>
  </motion.div>
))}
      </motion.div>

      {/* AI Features Highlight */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className="mt-24 max-w-7xl mx-auto bg-[#1A1A1A] rounded-2xl p-12 border border-[#4DA8FF]/30"
      >
        <h2 className="text-3xl font-extrabold text-center mb-12 text-[#4DA8FF]">
          All Plans Include AI-Powered Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-center text-gray-300">
          <div className="flex flex-col items-center">
            <Bot className="h-12 w-12 text-[#4DA8FF] mb-4" />
            <h3 className="text-xl font-semibold mb-2">Groq-Powered Insights</h3>
            <p>Advanced AI analysis of your infrastructure</p>
          </div>
          <div className="flex flex-col items-center">
            <Zap className="h-12 w-12 text-[#4DA8FF] mb-4" />
            <h3 className="text-xl font-semibold mb-2">Predictive Alerts</h3>
            <p>Prevent issues before they become problems</p>
          </div>
          <div className="flex flex-col items-center">
            <Shield className="h-12 w-12 text-[#4DA8FF] mb-4" />
            <h3 className="text-xl font-semibold mb-2">Intelligent Security</h3>
            <p>AI-driven threat detection and response</p>
          </div>
        </div>
      </motion.div>

      {/* FAQ Section */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        viewport={{ once: true }}
        className="mt-24 max-w-7xl mx-auto"
      >
        <h2 className="text-3xl font-extrabold text-center mb-12 text-[#4DA8FF]">
          Frequently Asked Questions
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              question: "Can I switch plans anytime?",
              answer: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately."
            },
            {
              question: "What's included in the free trial?",
              answer: "The free trial includes all Standard plan features for 14 days, no credit card required."
            },
            {
              question: "Do you offer custom enterprise solutions?",
              answer: "Yes, we provide tailored solutions for enterprise customers with specific requirements."
            },
            {
              question: "How does the AI analysis work?",
              answer: "Our AI uses Groq technology to analyze your infrastructure patterns and provide predictive insights."
            }
          ].map((faq, i) => (
            <div key={i} className="bg-[#1A1A1A] border border-[#4DA8FF]/30 rounded-2xl p-6">
              <h3 className="text-lg font-semibold mb-3 text-[#4DA8FF]">{faq.question}</h3>
              <p className="text-gray-400">{faq.answer}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Include CSS keyframes inside style tag */}
      <style>{`
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes lineMove {
          0% { transform: translateX(-50%) rotate(45deg); }
          100% { transform: translateX(150%) rotate(45deg); }
        }
        .animate-line {
          animation: lineMove 25s linear infinite;
        }
        .animate-gradient {
          animation: gradientShift 20s ease infinite;
        }
      `}</style>
    </div>
  );
}
