import React from 'react'

function Terms() {
  return (
    <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6 lg:px-8 text-gray-300">
      <h1 className="text-3xl font-bold text-white mb-6">Terms and Conditions</h1>
      <p className="text-sm text-yellow-400 mb-8">Last updated: June 25, 2025</p>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Interpretation and Definitions</h2>
        <h3 className="text-xl font-medium text-yellow-400 mt-4 mb-2">Interpretation</h3>
        <p className="mb-4">The words of which the initial letter is capitalized have meanings defined under the following conditions...</p>

        <h3 className="text-xl font-medium text-yellow-400 mt-6 mb-2">Definitions</h3>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Affiliate</strong> means an entity that controls, is controlled by or is under common control with a party...</li>
          <li><strong>Country</strong> refers to: Sri Lanka</li>
          <li><strong>Company</strong> refers to Automate AI, 327 Sri Nigrodharama Mawatha, Colombo.</li>
          <li><strong>Device</strong> means any device that can access the Service...</li>
          <li><strong>Service</strong> refers to the Website.</li>
          <li><strong>Terms and Conditions</strong> mean these Terms and Conditions...</li>
          <li><strong>Third-party Social Media Service</strong> means any services or content...</li>
          <li><strong>Website</strong> refers to TheAIToAutomate.com...</li>
          <li><strong>You</strong> means the individual accessing or using the Service...</li>
        </ul>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Acknowledgment</h2>
        <p className="mb-4">These are the Terms and Conditions governing the use of this Service and the agreement...</p>
        <p className="mb-4">By accessing or using the Service You agree to be bound by these Terms and Conditions...</p>
        <p className="mb-4">You represent that you are over the age of 18...</p>
        <p className="mb-4">Your access to and use of the Service is also conditioned on Your acceptance...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Links to Other Websites</h2>
        <p className="mb-4">Our Service may contain links to third-party web sites...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Termination</h2>
        <p className="mb-4">We may terminate or suspend Your access immediately...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Limitation of Liability</h2>
        <p className="mb-4">Notwithstanding any damages that You might incur...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">"AS IS" and "AS AVAILABLE" Disclaimer</h2>
        <p className="mb-4">The Service is provided to You "AS IS" and "AS AVAILABLE"...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Governing Law</h2>
        <p className="mb-4">The laws of the Country, excluding its conflicts of law rules...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Disputes Resolution</h2>
        <p className="mb-4">If You have any concern or dispute about the Service...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">For European Union (EU) Users</h2>
        <p className="mb-4">If You are a European Union consumer...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">United States Legal Compliance</h2>
        <p className="mb-4">You represent and warrant that (i) You are not located in a country...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Severability and Waiver</h2>
        <h3 className="text-xl font-medium text-yellow-400 mt-4 mb-2">Severability</h3>
        <p className="mb-4">If any provision of these Terms is held to be unenforceable or invalid...</p>
        <h3 className="text-xl font-medium text-yellow-400 mt-4 mb-2">Waiver</h3>
        <p className="mb-4">Except as provided herein, the failure to exercise a right...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Translation Interpretation</h2>
        <p className="mb-4">These Terms and Conditions may have been translated...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Changes to These Terms and Conditions</h2>
        <p className="mb-4">We reserve the right, at Our sole discretion, to modify or replace these Terms...</p>
      </section>

      <section className="mb-10">
        <h2 className="text-2xl font-semibold text-white mb-2">Contact Us</h2>
        <p className="mb-2">If you have any questions about these Terms and Conditions, You can contact us:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li>By email: support@theaitoautomate.com</li>
          <li>By visiting this page on our website: <a href="https://TheAIToAutomate.com" className="text-yellow-400 hover:underline">TheAIToAutomate.com</a></li>
          <li>By phone number: 0701568952</li>
        </ul>
      </section>
    </div>
  )
}

export default Terms