import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, User, ArrowRight, Bot, Cpu, Sparkles } from 'lucide-react';
import ReactMarkdown from "react-markdown";

export default function Blog() {
  const [showFullExcerpt, setShowFullExcerpt] = useState(false);

  const featuredPost = {
    title: "The Future of IT Automation: How AI is Revolutionizing Infrastructure Management",
    excerpt: `Artificial intelligence is no longer a futuristic dream—it’s fundamentally transforming IT infrastructure management today. From predictive maintenance that identifies failures before they disrupt operations to self‑healing systems that resolve issues autonomously, AI is redefining how data centers operate.

Organizations are integrating machine learning models to analyze real‑time performance metrics, detect anomalies instantly, and dynamically allocate resources based on workload demands. This means smarter, more resilient systems that adapt at the speed of your business.

Meanwhile, AI‑powered workflows are automating routine tasks—like patch updates, backup scheduling, and compliance enforcement—freeing teams to focus on strategic innovation. And with AI‑driven security and access controls, infrastructure becomes not only efficient, but inherently more secure.

The result? A future‑ready digital foundation: optimized, self‑managing, and intelligent, capable of powering the next wave of enterprise innovation.`,
    fullContent: `As technology becomes the backbone of every business operation, the way we manage IT infrastructure is undergoing a massive shift. Traditional, manual approaches to IT operations are giving way to smarter, faster, and more predictive systems, all thanks to artificial intelligence (AI).

Today, AI is revolutionizing IT infrastructure management by enabling automation that doesn’t just follow rules but also learns, adapts, and responds intelligently.

**What Is AI-Powered IT Automation?**  
IT automation traditionally involves scripting and software tools to perform repetitive tasks, like setting up servers, running backups, or deploying updates. With AI in the mix, these tasks become self-learning and adaptive, allowing systems to:  
- Monitor performance  
- Predict and prevent failures  
- Allocate resources intelligently  
- Auto-resolve common issues  

**How AI is Transforming [Infrastructure Management](https://zapier.com/blog/infrastructure-management/)**  
 
- **Predictive Maintenance**: AI analyzes usage patterns and system logs to predict hardware or software failures before they happen, reducing costly downtime.  
- **Real-Time Monitoring & Alerts**: AI tools monitor thousands of metrics simultaneously, instantly detecting anomalies and triggering alerts or automated fixes.  
- **Self-Healing Systems**: Instead of waiting for human intervention, AI-enabled infrastructure can fix issues automatically, such as restarting a failed service or reallocating resources.  
- **Smart Resource Allocation**: AI dynamically scales servers or network capacity based on demand, ensuring [optimal performance and reduced cloud costs](https://spot.io/resources/cloud-cost/cloud-cost-optimization-15-ways-to-optimize-your-cloud/).  
- **Enhanced Security**: AI strengthens cybersecurity by detecting suspicious behavior, blocking threats, and learning from new attack patterns to stay ahead.  

**Impact of AI**  
Industries like healthcare, finance, and e-commerce are already leveraging AI for smarter [IT operations](https://www.atlassian.com/itsm/it-operations).  
- Hospitals use AI for 24/7 uptime of patient systems.  
- Banks predict network congestion and reroute traffic.  
- Retailers auto-scale servers during flash sales to avoid crashes.  

**Benefits for Businesses**  
- **Efficiency**: Free up IT teams to focus on strategic tasks.  
- **Resilience**: Fewer outages and faster recovery.  
- **Scalability**: Easily adapt infrastructure to business growth.  
- **Cost Savings**: Optimize resource usage and reduce overprovisioning.  

**Challenges to Consider**  
- Integration with legacy systems  
- Data quality for accurate AI predictions  
- Skill gaps in AI and automation tools  
- Ethical concerns and data compliance  

**The Road Ahead**  
Looking forward, AI will drive [hyperautomation](https://www.gartner.com/en/information-technology/glossary/hyperautomation), where multiple systems, cloud apps, and security work together seamlessly. We'll also see the rise of AIops, digital twins of infrastructure for simulations, and self-managing cloud environments.  

**Conclusion**  
AI is not just optimizing IT infrastructure; it’s redefining it. For businesses, this means faster operations, fewer failures, and smarter systems that can grow and evolve with you. The future of infrastructure is intelligent, agile, and automated, and AI is at the core of that transformation. The time to embrace it is now.`,
    image: "/blog1.jpg",
    author: "Dr. Sarah Chen",
    date: "March 15, 2024",
    readTime: "8 min read",
    category: "AI Innovation"
  };

  const blogPosts = [
    {
      title: "Groq vs Traditional AI: Performance Benchmarks in Real-Time Monitoring",
      excerpt:
        "Explore an in-depth performance showdown between Groq’s ultra-fast inference engine and legacy AI models in real-time IT monitoring. From latency comparisons to throughput analysis, we break down how Groq is reshaping infrastructure intelligence and what it means for IT ops teams striving for zero-delay responsiveness.",
      image: "https://images.pexels.com/photos/8438993/pexels-photo-8438993.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Michael Rodriguez",
      date: "March 12, 2024",
      readTime: "6 min read",
      category: "Performance",
    },
    {
      title: "Top 5 Automated Tasks Every Modern IT Department Should Implement",
      excerpt:
        "Discover the five most impactful IT tasks that can and should be automated today—ranging from intelligent backup workflows and log parsing to proactive incident alerts and auto-scaling policies. Learn how automation saves time, reduces error, and keeps your digital infrastructure resilient and future-proof.",
      image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Jennifer Park",
      date: "March 10, 2024",
      readTime: "7 min read",
    },
    {
      title: "Securing AI-Powered Infrastructure: A Complete Guide",
      excerpt:
        "AI may optimize IT workflows, but without a strong security foundation, it opens the door to vulnerabilities. This guide outlines robust strategies for safeguarding AI-driven systems—from model integrity checks and data pipeline hardening to access control layers and zero-trust architectures.",
      image: "https://images.pexels.com/photos/5240547/pexels-photo-5240547.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "David Kim",
      date: "March 8, 2024",
      readTime: "10 min read",
    }
  ];

  return (
    <div className="min-h-screen bg-dark-bg text-white pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">

        {/* Featured Post */}
        <section className="mb-20">
          <h2 className="text-2xl lg:text-3xl font-bold text-white mb-6 flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-yellow-400" />
            Main Blog
          </h2>

          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative bg-dark-card border border-yellow-500 rounded-2xl overflow-hidden group hover:border-yellow-400 transition-all duration-300 shadow-lg"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative h-64 lg:h-auto">
                <img src={featuredPost.image} alt={featuredPost.title} className="w-full h-full object-cover" />
                <div className="absolute top-4 left-4">
                  <span className="bg-gradient-to-r from-yellow-300 to-orange-500 px-3 py-1 rounded-full text-sm font-medium text-black shadow-md">Featured</span>
                </div>
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="flex items-center space-x-4 text-sm text-gray-400 mb-4">
                  <span className="bg-yellow-500/10 text-yellow-400 px-3 py-1 rounded-full">{featuredPost.category}</span>
                  <span>{featuredPost.readTime}</span>
                </div>
                <h2 className="text-3xl font-bold mb-4 group-hover:text-yellow-400 transition-colors">
                  {featuredPost.title}
                </h2>

                <AnimatePresence initial={false} mode="wait">
                  <motion.div
                    key={showFullExcerpt ? "full" : "excerpt"}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.4 }}
                  >
                    <div className="text-gray-300 mb-6 leading-relaxed whitespace-pre-line">
                      <ReactMarkdown
                        components={{
                          a: ({ node, ...props }) => (
                            <a
                              {...props}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-yellow-400 hover:underline"
                            />
                          ),
                        }}
                      >
                        {showFullExcerpt ? featuredPost.fullContent : featuredPost.excerpt}
                      </ReactMarkdown>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {showFullExcerpt ? (
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => setShowFullExcerpt(false)}
                    className="
                      text-yellow-400
                      hover:underline
                      text-sm
                      transition-transform
                      duration-300
                      font-semibold
                      px-4
                      py-2
                      rounded-md
                      border
                      border-yellow-400
                      hover:bg-yellow-400
                      hover:text-black
                      shadow-md
                      hover:shadow-lg
                      focus:outline-none
                      focus:ring-2
                      focus:ring-yellow-400
                      cursor-pointer
                    "
                  >
                    Read Less
                  </motion.button>
                ) : (
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    whileHover={{ scale: 1.05 }}
                    onClick={() => setShowFullExcerpt(true)}
                    className="
                      text-yellow-400 
                      hover:underline 
                      text-sm 
                      transition-transform 
                      duration-300 
                      font-semibold 
                      px-4 
                      py-2 
                      rounded-md 
                      border 
                      border-yellow-400 
                      hover:bg-yellow-400 
                      hover:text-black 
                      shadow-md 
                      hover:shadow-lg
                      focus:outline-none 
                      focus:ring-2 
                      focus:ring-yellow-400
                      cursor-pointer
                    "
                  >
                    Read More
                  </motion.button>
                )}

                <div className="flex items-center justify-between mt-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-black" />
                    </div>
                    <div>
                      <p className="font-medium">{featuredPost.author}</p>
                      <p className="text-sm text-gray-400 flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {featuredPost.date}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Latest Posts */}

        {/* Latest News */}
        <div className="mb-6 mt-16">
          <h2 className="text-2xl lg:text-3xl font-bold text-white mb-4 flex items-center gap-2">
            <Cpu className="h-6 w-6 text-yellow-400" />
            Latest News
          </h2>
        </div>

        <motion.div
          initial="hidden"
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.1 } },
          }}
          className="space-y-6 max-w-3xl mx-auto"
        >
          {blogPosts.map((post, index) => (
            <motion.article
              key={index}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0 },
              }}
              className="flex items-center space-x-4 bg-dark-card border border-gray-700 rounded-lg p-4 hover:border-yellow-500 transition-colors cursor-pointer"
            >
              <img
                src={post.image}
                alt={post.title}
                className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
              />
              <div className="flex flex-col flex-grow">
                <h3 className="text-lg font-semibold text-white mb-1 leading-tight hover:text-yellow-400 transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-400 text-sm mb-1 line-clamp-2">{post.excerpt}</p>
                <div className="flex items-center text-xs text-gray-400 space-x-4 mt-auto">
                  <span>{post.readTime}</span>
                  <span className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>{post.date}</span>
                  </span>
                </div>
              </div>
              <ArrowRight className="h-5 w-5 text-yellow-400" />
            </motion.article>
          ))}
        </motion.div>

        {/* Newsletter Signup */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-20 max-w-xl mx-auto bg-yellow-600/10 border border-yellow-400 rounded-xl p-8 text-center"
        >
          <h2 className="text-2xl font-bold mb-4 text-yellow-400">
            Stay Updated with Our Blog
          </h2>
          <p className="text-gray-300 mb-6">
            Subscribe to receive the latest news and updates about IT automation and AI infrastructure.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              alert("Subscribed! (This is just a demo)");
            }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <input
              type="email"
              required
              placeholder="Enter your email"
              className="w-full sm:w-auto px-4 py-3 rounded-md border border-yellow-400 bg-transparent text-yellow-400 placeholder-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-yellow-400 text-black font-semibold rounded-md hover:bg-yellow-500 transition-colors shadow-md"
            >
              Subscribe
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
