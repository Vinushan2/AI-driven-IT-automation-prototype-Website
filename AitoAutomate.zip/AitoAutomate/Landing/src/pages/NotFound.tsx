import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFound = () => {
  const navigate = useNavigate();

  const goBack = () => {
    navigate('/');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white text-center p-6">
      <h1 className="text-6xl font-bold mb-4">404</h1>
      <p className="text-2xl mb-2">Oops! This page self-destructed 💥</p>
      <p className="text-md mb-6">
        Our AI tried to find this page but ended up chasing squirrels in the cloud ☁️🐿️
      </p>

      <img
        src="https://media.giphy.com/media/3og0INyCmHlNylks9O/giphy.gif"
        alt="Confused Robot"
        className="w-72 h-auto mb-6 rounded-xl shadow-lg"
      />

      <button
        onClick={goBack}
        className="px-6 py-3 bg-gradient-to-r from-pink-500 to-yellow-500 rounded-lg text-black font-bold hover:scale-105 transition-transform"
      >
        🏠 Beam me back home
      </button>

      <p className="mt-10 text-sm text-gray-400">theaitoautomate_signature_vinu2025</p>
    </div>
  );
};

export default NotFound;
