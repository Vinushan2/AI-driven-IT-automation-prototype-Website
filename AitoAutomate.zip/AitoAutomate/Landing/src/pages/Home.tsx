import React, { useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { motion, useMotionValue, useTransform } from "framer-motion";
import {
  Bot,
  Zap,
  Shield,
  BarChart3,
  ArrowRight,
  Cpu,
  AlertTriangle,
  Network,
  Brain,
  Settings,
  TrendingUp,
  Handshake,
  Lightbulb,
  CheckCircle,
  Activity
} from "lucide-react";

export default function Home() {
  const canvasRef = useRef(null);

  // Particle Effect (unchanged)
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    let particles = [];
    const mouse = { x: null, y: null, radius: 100 };

    const handleMouseMove = (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };

    const initParticles = () => {
      particles = [];
      for (let i = 0; i < 100; i++) {
        particles.push({
          x: Math.random() * window.innerWidth,
          y: Math.random() * window.innerHeight,
          radius: Math.random() * 2 + 1,
          dx: (Math.random() - 0.5) * 1,
          dy: (Math.random() - 0.5) * 1,
        });
      }
    };

    const drawParticles = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#FFC10788";

      particles.forEach((p) => {
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < mouse.radius) {
          const angle = Math.atan2(dy, dx);
          const force = (mouse.radius - dist) / mouse.radius;
          const repulse = force * 4;

          p.x -= Math.cos(angle) * repulse;
          p.y -= Math.sin(angle) * repulse;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();

        p.x += p.dx;
        p.y += p.dy;

        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
      });

      requestAnimationFrame(drawParticles);
    };

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    initParticles();
    drawParticles();

    window.addEventListener("resize", () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initParticles();
    });

    window.addEventListener("mousemove", handleMouseMove);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, []);

  const benefits = [
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Predictive Maintenance",
      description: "AI-powered predictions prevent system failures before they occur",
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Infrastructure Automation",
      description: "Automate complex IT tasks with intelligent workflow orchestration",
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "AI-Powered Alerts",
      description: "Smart notifications that reduce noise and focus on critical issues",
    },
  ];

  const useCases = [
    {
      icon: <Cpu className="h-6 w-6" />,
      title: "Server Health Monitoring",
      description: "Real-time monitoring with predictive analytics",
    },
    {
      icon: <AlertTriangle className="h-6 w-6" />,
      title: "Incident Response",
      description: "Automated incident detection and resolution",
    },
    {
      icon: <Network className="h-6 w-6" />,
      title: "Access Management",
      description: "Intelligent user access automation and security",
    },
  ];

  const technologies = [
  {
    name: "Groq AI",
    logo: "🧠",
    url: "https://groq.com/",
  },
  {
    name: "Firebase",
    logo: "🔥",
    url: "https://firebase.google.com/",
  },
  {
    name: "React",
    logo: "⚛️",
    url: "https://react.dev/",
  },
  {
    name: "Tailwind CSS",
    logo: "💨",
    url: "https://tailwindcss.com/",
  },
];



  const whatWeDoItems = [
    {
      icon: <Brain className="h-8 w-8" />,
      title: "Intelligent IT Solutions",
      description:
        "Leveraging advanced AI models to provide smart solutions for complex IT challenges, enhancing operational intelligence.",
    },
    {
      icon: <Settings className="h-8 w-8" />,
      title: "Workflow Automation",
      description:
        "Streamlining IT workflows and reducing manual efforts through seamless, AI-driven automation.",
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      title: "System Efficiency & Optimization",
      description:
        "Improving overall system performance and efficiency with AI-powered predictive capabilities and resource management.",
    },
  ];

  const howItWorksSteps = [
    {
      step: "1. Data Ingestion & Analysis",
      description:
        "Our platform collects vast amounts of IT operational data, from logs to performance metrics, and uses AI to analyze it for patterns and anomalies.",
    },
    {
      step: "2. AI-Powered Insights",
      description:
        "Advanced AI models process the data, generating actionable insights, predictive alerts, and identifying potential issues before they impact your systems.",
    },
    {
      step: "3. Automated Action & Remediation",
      description:
        "Based on the AI-driven insights, our automation tools automatically execute tasks, resolve incidents, and optimize infrastructure, minimizing downtime and manual intervention.",
    },
  ];

  const successStories = [
    {
      quote:
        "The AI To Automate revolutionized our infrastructure management. We saw a 30% reduction in downtime within the first quarter!",
      author: "CEO, TechInnovate Solutions",
      icon: <CheckCircle className="h-6 w-6 text-[#FFC107]" />,
    },
    {
      quote:
        "Implementing their AI-powered automation saved us countless hours on manual tasks. Our team can now focus on strategic initiatives.",
      author: "IT Director, Global Enterprises",
      icon: <CheckCircle className="h-6 w-6 text-[#FFC107]" />,
    },
    {
      quote:
        "The predictive maintenance capabilities are outstanding. We've gone from reactive troubleshooting to proactive problem solving.",
      author: "Operations Lead, Digital Dynamics",
      icon: <CheckCircle className="h-6 w-6 text-[#FFC107]" />,
    },
  ];

  const aiTechItems = [
  {
    icon: <Lightbulb className="h-10 w-10 text-[#FFC107]" />,
    title: "AI-Driven Anomaly Detection",
    description:
      "Automatically identify unusual patterns in your system operations before they escalate.",
    link: "/solutions",
  },
  {
    icon: <Handshake className="h-10 w-10 text-[#FFC107]" />,
    title: "Self-Healing Systems",
    description:
      "Systems that detect and remediate faults autonomously without human intervention.",
    link: "/solutions",
  },
  {
    icon: <Brain className="h-10 w-10 text-[#FFC107]" />,
    title: "Cognitive Automation",
    description:
      "Utilize AI to automate complex decision-making workflows in real time.",
    link: "/solutions",
  },
  {
    icon: <Cpu className="h-10 w-10 text-[#FFC107]" />,
    title: "Predictive Resource Allocation",
    description:
      "Optimize resource usage by forecasting demand and scaling dynamically.",
    link: "/solutions",
  },
  {
    icon: <Activity className="h-10 w-10 text-[#FFC107]" />,
    title: "Real-Time Health Monitoring",
    description:
      "Continuously track system vitals to ensure optimal performance and uptime.",
    link: "/solutions",
  },
  {
    icon: <Settings className="h-10 w-10 text-[#FFC107]" />,
    title: "Autonomous Optimization",
    description:
      "Continuously fine-tune system performance through intelligent feedback loops.",
    link: "/solutions",
  },
];


  // TiltCard with gradient + gold shadows + smooth tilt motion
  function TiltCard({ icon, title, description }) {
    const x = useMotionValue(0);
    const y = useMotionValue(0);

    const rotateX = useTransform(y, [50, -50], [-12, 12]);
    const rotateY = useTransform(x, [-50, 50], [-12, 12]);

    const handleMouseMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const posX = e.clientX - rect.left - rect.width / 2;
      const posY = e.clientY - rect.top - rect.height / 2;
      x.set(posX);
      y.set(posY);
    };

    const handleMouseLeave = () => {
      x.set(0);
      y.set(0);
    };

    return (
      <motion.div
        className="bg-gradient-to-br from-[#1b0a3d] via-[#150018] to-[#000000] border border-[#FFC107]/50 rounded-xl p-6 shadow-[0_0_30px_#FFC107] cursor-pointer relative"
        style={{
          rotateX,
          rotateY,
          perspective: 650,
          boxShadow: `0 15px 35px rgba(255, 193, 7, 0.6), 0 0 20px rgba(255, 193, 7, 0.4)`,
          transformStyle: "preserve-3d",
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        whileTap={{ scale: 0.95 }}
        whileHover={{ scale: 1.05 }}
      >
        <div className="text-[#FFC107] mb-4">{icon}</div>
        <h3 className="text-xl font-extrabold mb-2 tracking-wide">{title}</h3>
        <p className="text-gray-300">{description}</p>
      </motion.div>
    );
  }

  // Wrapper for sections using TiltCards to keep code DRY
  function TiltCardsGrid({ items }) {
    return (
      <div className="grid md:grid-cols-3 gap-8">
        {items.map(({ icon, title, description }, idx) => (
          <TiltCard key={idx} icon={icon} title={title} description={description} />
        ))}
      </div>
    );
  }

  return (
    <div className="relative bg-gradient-to-br from-[#0c001a] via-[#150018] to-black text-white min-h-screen overflow-x-hidden">
      <canvas
        ref={canvasRef}
        className="fixed top-0 left-0 w-full h-full pointer-events-none z-0"
      />
      <div className="relative z-10 max-w-6xl mx-auto px-6 pt-20 pb-20">

        {/* Intro Section */}
        <motion.section
  initial={{ opacity: 0, y: 60 }}
  whileInView={{ opacity: 1, y: 0 }}
  transition={{ duration: 1 }}
  viewport={{ once: true }}
  className="text-center max-w-3xl mx-auto mb-20 relative px-4"
>
  <motion.h1
    className="font-extrabold mb-6 tracking-tight bg-gradient-to-r from-[#FFC107] via-[#4DA8FF] to-[#1E40AF] bg-clip-text text-transparent relative inline-block drop-shadow-[0_0_10px_rgba(255,193,7,0.9)] drop-shadow-[0_0_20px_rgba(77,168,255,0.7)]"
    style={{ fontFamily: "'Fira Mono', monospace" }}
    initial={{ fontSize: "3rem" }} // ~5xl
    animate={{ fontSize: "3.75rem" }} // ~6xl
    transition={{ duration: 2, repeat: Infinity, repeatType: "mirror", ease: "easeInOut" }}
  >
    AI To Automate
    {/* Animated sparkle underline */}
    <span className="absolute left-0 bottom-0 w-full h-1 bg-gradient-to-r from-yellow-400 via-blue-400 to-yellow-400 rounded-full animate-pulseGlow"></span>
  </motion.h1>
  <p className="text-lg text-blue-300 mb-8 max-w-xl mx-auto">
    Revolutionizing Infrastructure Automation with Artificial Intelligence
  </p>
  <a
  href="https://app.TheAIToAutomate.com"
  target="_blank"
  rel="noopener noreferrer"
  className="inline-flex items-center gap-2 px-8 py-3 rounded-full bg-gradient-to-r from-[#FFC107] via-[#4DA8FF] to-[#1E40AF] text-black font-bold shadow-lg shadow-yellow-400/50 transition-all hover:brightness-110 hover:shadow-blue-500/70"
>
  Explore Dashboard <ArrowRight className="w-5 h-5 text-black" />
</a>


  <style>{`
    @keyframes pulseGlow {
      0%, 100% {
        opacity: 0.5;
        transform: scaleX(1);
      }
      50% {
        opacity: 1;
        transform: scaleX(1.05);
      }
    }
    .animate-pulseGlow {
      animation: pulseGlow 2.5s ease-in-out infinite;
    }
  `}</style>
</motion.section>


        {/* Benefits Section */}
        <motion.section
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-20 max-w-5xl mx-auto"
        >
          <h2 className="text-4xl font-bold mb-12 text-[#FFC107] text-center drop-shadow-[0_0_10px_rgba(255,193,7,0.8)]">
            Benefits
          </h2>
          <TiltCardsGrid items={benefits} />
        </motion.section>

        {/* What We Do Section */}
        <motion.section
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-20 max-w-5xl mx-auto"
        >
          <h2 className="text-4xl font-bold mb-12 text-[#FFC107] text-center drop-shadow-[0_0_10px_rgba(255,193,7,0.8)]">
            What We Do
          </h2>
          <TiltCardsGrid items={whatWeDoItems} />
        </motion.section>

        {/* How It Works Section */}
        <motion.section
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          viewport={{ once: true }}
          className="mb-20 max-w-5xl mx-auto space-y-8"
        >
          <h2 className="text-4xl font-bold mb-8 text-[#FFC107] text-center drop-shadow-[0_0_10px_rgba(255,193,7,0.8)]">
            How It Works
          </h2>
          {howItWorksSteps.map(({ step, description }, idx) => (
            <TiltCard
              key={idx}
              icon={<ArrowRight className="h-8 w-8 text-[#FFC107]" />}
              title={step}
              description={description}
            />
          ))}
        </motion.section>

        {/* Success Stories Section */}
        <motion.section
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          viewport={{ once: true }}
          className="mb-20 max-w-5xl mx-auto"
        >
          <h2 className="text-4xl font-bold mb-12 text-[#FFC107] text-center drop-shadow-[0_0_10px_rgba(255,193,7,0.8)]">
            Success Stories
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {successStories.map(({ quote, author, icon }, idx) => (
              <TiltCard
                key={idx}
                icon={icon}
                title={`"${quote}"`}
                description={`- ${author}`}
              />
            ))}
          </div>
        </motion.section>

        <motion.section
  initial={{ opacity: 0, y: 60 }}
  whileInView={{ opacity: 1, y: 0 }}
  transition={{ duration: 1, delay: 1 }}
  viewport={{ once: true }}
  className="mb-20 max-w-5xl mx-auto relative"
>
  {/* Animated Gradient Background for Heading */}
  <h2 className="relative text-4xl font-bold mb-12 text-[#FFC107] text-center drop-shadow-[0_0_20px_rgba(255,193,7,1)] z-10">
    <span className="relative z-10">AI Automated Technologies</span>
    <span
      aria-hidden="true"
      className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500 opacity-30 rounded-lg blur-xl animate-gradient-x"
      style={{ filter: "blur(25px)" }}
    />
  </h2>

  {/* Grid with staggered animation and glowing borders */}
  <motion.div
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    variants={{
      visible: {
        transition: {
          staggerChildren: 0.15,
        },
      },
      hidden: {},
    }}
    className="grid md:grid-cols-3 gap-8"
  >
    {aiTechItems.map(({ icon, title, description, link }, idx) => (
  <motion.div
    key={idx}
    variants={{
      hidden: { opacity: 0, y: 30 },
      visible: { opacity: 1, y: 0 },
    }}
    whileHover={{
      scale: 1.1,
      boxShadow: "0 0 20px 4px #FFC107AA, 0 0 40px 10px #FFC10766",
    }}
    className="relative rounded-xl border border-yellow-500/40 p-6 shadow-md shadow-yellow-700/20 bg-gradient-to-tr from-[#1b0a3d] via-[#150018] to-[#000000] cursor-pointer flex flex-col justify-between"
    style={{
      boxShadow:
        "0 0 20px 2px rgba(255, 193, 7, 0.5), inset 0 0 15px 3px rgba(255, 193, 7, 0.3)",
      transition: "box-shadow 0.3s ease, transform 0.3s ease",
      minHeight: "250px",
    }}
  >
    <div>
      <div className="text-[#FFC107] mb-4 drop-shadow-[0_0_8px_rgba(255,193,7,0.9)]">
        {icon}
      </div>
      <h3 className="text-xl font-extrabold mb-2 tracking-wide">{title}</h3>
      <p className="text-gray-300">{description}</p>
    </div>
    <Link
      to={link}
      className="mt-6 inline-block self-start px-5 py-2 rounded-full bg-yellow-400 text-black font-semibold shadow-lg hover:bg-yellow-300 hover:shadow-yellow-400/60 transition"
      onClick={(e) => e.stopPropagation()} // prevent card click if any
    >
      Learn More →
    </Link>
  </motion.div>
))}
  </motion.div>

  <style>{`
    @keyframes gradient-x {
      0%, 100% {
        background-position: 0% 50%;
      }
      50% {
        background-position: 100% 50%;
      }
    }
    .animate-gradient-x {
      background-size: 200% 200%;
      animation: gradient-x 6s ease infinite;
    }
  `}</style>
</motion.section>


        {/* Powered By Tech Section */}
        <motion.section
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.2 }}
          viewport={{ once: true }}
          className="mb-20 max-w-4xl mx-auto"
        >
          <h2 className="text-3xl font-bold mb-8 text-[#FFC107] text-center drop-shadow-[0_0_10px_rgba(255,193,7,0.8)]">
            Powered by Tech
          </h2>
          <div className="flex justify-center gap-12 text-5xl">
            {technologies.map(({ name, logo, url }, idx) => (
  <motion.a
    key={idx}
    whileHover={{ scale: 1.2 }}
    href={url}
    target="_blank"
    rel="noopener noreferrer"
    className="flex flex-col items-center text-[#FFC107] cursor-pointer select-none"
    title={name}
  >
    <span>{logo}</span>
    <span className="mt-2 text-lg font-semibold text-center">{name}</span>
  </motion.a>
))}

          </div>
        </motion.section>
      </div>
    </div>
  );
}
