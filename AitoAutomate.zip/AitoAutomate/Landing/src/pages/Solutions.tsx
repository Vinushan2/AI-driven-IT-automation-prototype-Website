import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import Tilt from "react-parallax-tilt";
import { Bot, Zap, Shield, BarChart3, ArrowRight,Cpu,Code2,Settings, Database} from "lucide-react";

export default function Solutions() {
  const solutions = [
  {
    icon: <Bot className="h-10 w-10 text-[#FFC107]" />,
    title: "AI-Powered Monitoring",
    description: "Continuous monitoring with anomaly detection and predictive insights.",
    features: [
      "Real-time system health tracking",
      "Anomaly detection with ML",
      "Predictive failure analysis",
      "Custom alert thresholds",
    ],
  },
  {
    icon: <Zap className="h-10 w-10 text-[#4DA8FF]" />,
    title: "Automated Workflows",
    description: "Streamline operations with automation that adapts to your infrastructure.",
    features: [
      "Workflow orchestration",
      "Event-driven triggers",
      "Multi-step automation",
      "Toolchain integrations",
    ],
  },
  {
    icon: <Shield className="h-10 w-10 text-[#FFC107]" />,
    title: "Security Automation",
    description: "Proactive security with AI-driven threat detection and incident response.",
    features: [
      "Threat detection automation",
      "Incident response workflows",
      "Compliance reporting",
      "Access control",
    ],
  },
  {
    icon: <BarChart3 className="h-10 w-10 text-[#4DA8FF]" />,
    title: "Performance Analytics",
    description: "Deep insights into system performance and optimization suggestions.",
    features: [
      "Trend analysis",
      "Resource optimization",
      "Capacity planning",
      "Custom dashboards",
    ],
  },
  {
    icon: <Cpu className="h-10 w-10 text-[#FFC107]" />,
    title: "Predictive Scaling",
    description: "Scale infrastructure proactively based on usage trends and ML predictions.",
    features: [
      "AI-based load prediction",
      "Auto-scaling policies",
      "Cost-efficient resource planning",
      "Cloud-native integrations",
    ],
  },
  {
    icon: <Settings className="h-10 w-10 text-[#4DA8FF]" />,
    title: "Self-Healing Systems",
    description: "Recover from faults automatically with predefined remediation logic.",
    features: [
      "Automated incident resolution",
      "Root cause detection",
      "Resilient system design",
      "Failure pattern learning",
    ],
  },
  {
    icon: <Database className="h-10 w-10 text-[#FFC107]" />,
    title: "Data Intelligence",
    description: "Extract actionable insights from log data and telemetry streams.",
    features: [
      "AI log analysis",
      "Structured & unstructured data support",
      "Data correlation across sources",
      "Smart tagging & search",
    ],
  },
  {
    icon: <Code2 className="h-10 w-10 text-[#4DA8FF]" />,
    title: "DevOps Intelligence",
    description: "Enhance CI/CD pipelines with intelligent automation and feedback loops.",
    features: [
      "Deployment risk prediction",
      "Test coverage analysis",
      "Rollback automation",
      "Pipeline health metrics",
    ],
  },
];

  const containerVariants = {
    hidden: {},
    show: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 60 } },
  };

  return (
    <div className="relative min-h-screen bg-[#0D0D0D] text-white py-20 px-4 overflow-hidden">
      {/* Background Animated Gradient */}
      <div
        className="absolute inset-0 -z-10 animate-gradient bg-gradient-to-r from-[#FFC107] via-[#4DA8FF] to-[#1E40AF] opacity-30"
        style={{
          backgroundSize: "600% 600%",
          animation: "gradientShift 20s ease infinite",
        }}
      />

      {/* Animated Glowing Lines */}
      <div className="absolute inset-0 -z-20">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute w-[150%] h-[2px] bg-blue-400 opacity-10 blur-md animate-line"
            style={{
              top: `${i * 20 + 10}%`,
              left: `-${i * 10}%`,
              animationDelay: `${i * 3}s`,
              transform: "rotate(45deg)",
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="text-center mb-20 relative max-w-3xl mx-auto px-4"
      >
        <motion.h1
          className="font-extrabold tracking-tight bg-gradient-to-r from-[#FFC107] via-[#4DA8FF] to-[#1E40AF] bg-clip-text text-transparent relative inline-block drop-shadow-[0_0_10px_rgba(255,193,7,0.9)] drop-shadow-[0_0_20px_rgba(77,168,255,0.7)]"
          style={{ fontFamily: "'Fira Mono', monospace" }}
          initial={{ fontSize: "3rem" }} // ~5xl
          animate={{ fontSize: "3.75rem" }} // ~6xl
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
          }}
        >
          AI-Powered
          <br />
          IT Solutions

          {/* Animated sparkle underline */}
          <span className="absolute left-0 bottom-0 w-full h-1 bg-gradient-to-r from-yellow-400 via-blue-400 to-yellow-400 rounded-full animate-pulseGlow"></span>
        </motion.h1>
        <p className="text-lg md:text-xl text-blue-300 mt-6 max-w-xl mx-auto">
          Transform your IT operations with automation, insights, and seamless integration.
        </p>
      </motion.div>

      {/* Cards Section */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
      >
        {solutions.map((solution, index) => (
          <motion.div key={index} variants={cardVariants}>
            <Tilt
              tiltMaxAngleX={10}
              tiltMaxAngleY={10}
              glareEnable
              glareColor="#4DA8FF"
              className="bg-[#1A1A1A] p-6 rounded-2xl border border-[#4DA8FF]/30 shadow-[0_0_15px_#4DA8FF33] hover:shadow-[0_0_25px_#4DA8FFAA] transition-shadow duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                {solution.icon}
                <h3 className="text-2xl font-semibold text-white">{solution.title}</h3>
              </div>
              <p className="text-gray-300 mb-4">{solution.description}</p>
              <ul className="list-disc pl-6 text-sm text-gray-400 space-y-1">
                {solution.features.map((f, i) => (
                  <li key={i}>{f}</li>
                ))}
              </ul>
            </Tilt>
          </motion.div>
        ))}
      </motion.div>

      {/* CTA */}
      <motion.div
        className="text-center mt-24"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        <a
  href="https://app.TheAIToAutomate.com"
  target="_blank"
  rel="noopener noreferrer"
  className="inline-flex items-center px-8 py-4 text-xl font-bold rounded-full bg-gradient-to-r from-[#FFC107] via-[#4DA8FF] to-[#1E40AF] text-black hover:scale-105 transition-transform"
>
  Get Started <ArrowRight className="ml-3 h-5 w-5" />
</a>

      </motion.div>

      {/* Include CSS keyframes inside style tag */}
      <style>{`
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        @keyframes lineMove {
          0% { transform: translateX(-50%) rotate(45deg); }
          100% { transform: translateX(150%) rotate(45deg); }
        }
        @keyframes pulseGlow {
          0%, 100% {
            opacity: 0.5;
            transform: scaleX(1);
          }
          50% {
            opacity: 1;
            transform: scaleX(1.05);
          }
        }
        .animate-line {
          animation: lineMove 25s linear infinite;
        }
        .animate-gradient {
          animation: gradientShift 20s ease infinite;
        }
        .animate-pulseGlow {
          animation: pulseGlow 2.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
