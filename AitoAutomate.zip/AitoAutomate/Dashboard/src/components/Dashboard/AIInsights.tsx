import React, { useState } from 'react';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import { Zap, RefreshCw } from 'lucide-react';
import { fetchAIRecommendation } from '@services/groqService.js';

const AIInsights: React.FC = () => {
  const [aiInsight, setAIInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [userPrompt, setUserPrompt] = useState('');
  const [userAIResponse, setUserAIResponse] = useState<string | null>(null);
  const [userAIError, setUserAIError] = useState<string | null>(null);

  const handleRunAI = async () => {
    setLoading(true);
    try {
      const prompt = `Here's the current server status:\n- CPU Load: 82%\n- Memory Usage: 68%\n- Recent Errors: 5 authentication failures on node-x4\nProvide recommendations to improve system health and reliability.`;
      const result = await fetchAIRecommendation(prompt);
      setAIInsight(result);
    } catch (e) {
      setAIInsight('Failed to fetch AI insights.');
    } finally {
      setLoading(false);
    }
  };

  const handleUserPromptSubmit = async () => {
    setUserAIError(null);
    setUserAIResponse(null);
    setLoading(true);

    if (!userPrompt.trim()) {
      setUserAIError('Please enter a valid prompt.');
      setLoading(false);
      return;
    }

    try {
      const result = await fetchAIRecommendation(userPrompt);
      if (!result || typeof result !== 'string') {
        throw new Error('Invalid response from Groq.');
      }
      setUserAIResponse(result);
    } catch (error) {
      setUserAIError('Groq AI is currently unavailable or unsupported. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const uptimeData = [
    { name: 'Mon', uptime: 99.9, incidents: 0 },
    { name: 'Tue', uptime: 99.8, incidents: 1 },
    { name: 'Wed', uptime: 99.9, incidents: 0 },
    { name: 'Thu', uptime: 98.5, incidents: 3 },
    { name: 'Fri', uptime: 99.7, incidents: 1 },
    { name: 'Sat', uptime: 99.9, incidents: 0 },
    { name: 'Sun', uptime: 99.8, incidents: 0 },
  ];

  const performanceData = [
  { name: 'CPU', value: 65, color: '#7e22ce' },      // Vivid Purple
  { name: 'Memory', value: 78, color: '#14b8a6' },   // Teal
  { name: 'Disk', value: 45, color: '#f97316' },     // Orange
  { name: 'Network', value: 89, color: '#0ea5e9' },  // Sky Blue
];


  const incidentData = [
  { name: 'Critical', value: 2, color: '#dc2626' },   // Bright Red
  { name: 'Warning', value: 8, color: '#facc15' },    // Yellow Gold
  { name: 'Info', value: 23, color: '#6366f1' },      // Indigo
  { name: 'Resolved', value: 45, color: '#22c55e' },  // Green
];



  const recommendations = [
    {
      id: 1,
      title: 'Optimize Database Queries',
      description: 'AI detected 15% performance improvement potential in database operations',
      impact: 'High',
      effort: 'Medium',
      category: 'Performance'
    },
    {
      id: 2,
      title: 'Scale Web Server Cluster',
      description: 'Current load approaching 80% capacity. Consider adding 2 more instances',
      impact: 'High',
      effort: 'Low',
      category: 'Infrastructure'
    },
    {
      id: 3,
      title: 'Update Security Policies',
      description: 'Anomaly detection suggests reviewing access patterns for user group "Admins"',
      impact: 'Medium',
      effort: 'High',
      category: 'Security'
    },
    {
      id: 4,
      title: 'Cache Optimization',
      description: 'Redis cache hit rate can be improved by 23% with TTL adjustments',
      impact: 'Medium',
      effort: 'Low',
      category: 'Performance'
    }
  ];

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'High': return 'text-red-600 bg-red-100 border-red-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'Low': return 'text-green-600 bg-green-100 border-green-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Performance': return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'Infrastructure': return 'text-purple-600 bg-purple-100 border-purple-200';
      case 'Security': return 'text-red-600 bg-red-100 border-red-200';
      default: return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex space-x-3">
            <button
              onClick={handleRunAI}
              disabled={loading}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 disabled:opacity-50"
            >
              <Zap className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Running...' : 'Run with  AI'}</span>
            </button>
          </div>
        </div>

        {aiInsight && (
          <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <h5 className="text-sm font-semibold text-gray-700 mb-2">Groq AI Recommendation:</h5>
            <p className="text-sm text-gray-800 whitespace-pre-line">{aiInsight}</p>
          </div>
        )}

        <div className="mt-6">
          <h4 className="text-md font-semibold text-gray-800 mb-2">Ask a custom question:</h4>
          <textarea
            className="w-full p-2 border border-gray-300 rounded-lg mb-2 text-sm"
            placeholder="e.g., How can I reduce memory usage on weekends?"
            value={userPrompt}
            onChange={(e) => setUserPrompt(e.target.value)}
          />
          <button
            onClick={handleUserPromptSubmit}
            disabled={loading}
            className="px-4 py-2 bg-yellow-500 text-white text-sm rounded hover:bg-yellow-600 transition-colors"
          >
            {loading ? 'Analyzing...' : 'Submit to AI'}
          </button>
          {userAIError && <p className="text-red-500 mt-2 text-sm">{userAIError}</p>}
          {userAIResponse && (
            <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg">
              <h5 className="text-sm font-semibold text-gray-700 mb-2">Response:</h5>
              <p className="text-sm text-gray-800 whitespace-pre-line">{userAIResponse}</p>
            </div>
          )}
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6" style={{
    borderColor: '#2958c2',
    borderWidth: '2px'
  }}>
          <h4 className="text-lg font-semibold text-gray-800 mb-4">System Uptime & Incidents</h4>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={uptimeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="uptime" stroke="#10b981" strokeWidth={2} />
              <Line type="monotone" dataKey="incidents" stroke="#ef4444" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6" style={{
    borderColor: '#2958c2',
    borderWidth: '2px'
  }}>
          <h4 className="text-lg font-semibold text-gray-800 mb-4" >Resource Utilization</h4>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value">
                {performanceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-800 mb-4">Incident Distribution</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={incidentData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {incidentData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>

          <div className="space-y-4">
            <h5 className="font-semibold text-gray-800">Key Metrics</h5>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xl font-bold text-blue-600">78</div>
                <div className="text-sm text-gray-600">Total Incidents</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="text-xl font-bold text-green-600">57.7%</div>
                <div className="text-sm text-gray-600">Resolution Rate</div>
              </div>
              <div className="text-center p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="text-xl font-bold text-yellow-600">12m</div>
                <div className="text-sm text-gray-600">Avg. Response</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg border border-purple-200">
                <div className="text-xl font-bold text-purple-600">4.2</div>
                <div className="text-sm text-gray-600">AI Score</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h4 className="text-lg font-semibold text-gray-800 mb-6">AI Recommendations</h4>
        <div className="space-y-4" >
          {recommendations.map((rec) => (
            <div key={rec.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors duration-200" style={{
    borderColor: '#2958c2',
    borderWidth: '2px'
  }}>
              <div className="flex items-start justify-between mb-2" >
                <h5 className="font-semibold text-gray-800">{rec.title}</h5>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getCategoryColor(rec.category)}`}>
                    {rec.category}
                  </span>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full border ${getImpactColor(rec.impact)}`}>
                    {rec.impact} Impact
                  </span>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-3">{rec.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">Effort: {rec.effort}</span>
                <button className="px-3 py-1 bg-yellow-500 text-white text-xs rounded-lg hover:bg-yellow-600 transition-colors duration-200">
                  Apply Suggestion
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AIInsights;
