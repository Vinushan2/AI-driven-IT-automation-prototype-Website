import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// Firebase configuration - Replace with your actual config
const firebaseConfig = {
   apiKey: "AIzaSyBGQEiYwCDy9otl3sYK3GDM5BFIBlgtJD4",
  authDomain: "theaitoautomate-login.firebaseapp.com",
  projectId: "theaitoautomate-login",
  storageBucket: "theaitoautomate-login.firebasestorage.app",
  messagingSenderId: "519215999206",
  appId: "1:519215999206:web:28f42d36039d5594b97327"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);
export default app;